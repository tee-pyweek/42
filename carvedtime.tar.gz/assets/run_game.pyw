#! /usr/bin/env python

import asyncio

from gamelib import main


asyncio.run(main.main())
