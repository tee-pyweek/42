Carved Time
===========

Entry in PyWeek #42  <http://www.pyweek.org/42/>
Team: Tee-py42
Members: Tee


DEPENDENCIES:

You might need to install some of these before running the game:

  Python 3:   http://www.python.org/
  PyGame-CE:  http://www.pyga.me/

You can install dependencies with `pip install -r requirements.txt`.
PyTMX is bundled in the "pytmx" folder.


RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.py" file and double-click it.

Otherwise open a terminal / console and "cd" to the game directory and run:

  python run_game.py

To build the web version with pygbag 0.9.3 (https://pypi.org/project/pygbag/), run
this from the game directory:

  python -m pygbag --build --no_opt --template web.tmpl .

Then serve build/web and open http://127.0.0.1:8000. Use a plain server and
127.0.0.1 rather than pygbag's own test server at localhost, which swaps in local
copies of the packages and so can hide problems that appear once published:

  python -m http.server 8000 -d build/web


HOW TO PLAY THE GAME:

Instructions are in-game, but here is a brief description:

This is a skill-based puzzly platformer. Your timeline is interleaved with a
moving clock. Every 5 seconds, the clock moves and brings you with it. You need
to get to the end of the clock track, using the clock movement effectively to
get through walls. Throughout the track, you must collect energy charges and
charge each checkpoint.

Controls:
* WASD/Arrow keys to move
* X/C/Space to jump
* R to restart
* F for full screen
* ESC for menu


GENERATIVE AI USE:

Generative AI was used in coding. Everything else was created with no AI use
or sourced below.


LICENSE:

Carved Time (code and art) is under the zlib license:

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.


Libraries:
pygame-text: https://github.com/cosmologicon/pygame-text (CC0 1.0 Universal), by Cosmologicon
PyTMX: https://github.com/bitcraft/pytmx (LGPL 3.0, see pytmx/LICENSE), by bitcraft

Fonts:
Dogica: https://www.dafont.com/dogica.font (see link)
Timeline: https://www.dafont.com/timeline.font (see link)

Music:
* "Loopster" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
http://creativecommons.org/licenses/by/4.0/

Sounds:
pickup.ogg: https://freesound.org/people/The-Sacha-Rush/sounds/657823/ (https://creativecommons.org/publicdomain/zero/1.0/)
charge.ogg: https://freesound.org/people/JavierZumer/sounds/257229/, modified (https://creativecommons.org/licenses/by/4.0/)
tick.ogg: https://freesound.org/people/day-garwood/sounds/619276/, modified (https://creativecommons.org/licenses/by/3.0/)
clock_move.ogg: https://freesound.org/people/Patrick_Corra/sounds/466451/ (https://creativecommons.org/licenses/by/4.0/)
Created with jsfxr (https://sfxr.me/): jump.ogg, death.ogg, launch.ogg

Palette:
https://lospec.com/palette-list/rust-gold-8
