import sys

import pygame

from . import data

IS_WEB = sys.platform == "emscripten"  # Running in the browser under pygbag.

FPS = 50
MAX_DT = 0.05
SCALE = 3

REAL_WIDTH = 384
REAL_HEIGHT = 288

WIDTH = REAL_WIDTH * SCALE
HEIGHT = REAL_HEIGHT * SCALE

FONT_MAIN = data.filepath("dogicapixel.ttf")
FONT_DISPLAY = data.filepath("Timeline.ttf")

TEXT_LINE_GAP = 2  # Between lines of multiline text, in pixels.

# Palette colors.
MID_BROWN_COLOR = (114, 89, 86)
WHITE_COLOR = (244, 233, 221)
GOLD_COLOR = (246, 205, 38)
DARK_BROWN_COLOR = (51, 28, 23)
COPPER_COLOR = (172, 107, 38)
TAN_COLOR = (187, 127, 87)

TILE_SIZE = 24

# Key constants.
JUMP_KEYS = (pygame.K_SPACE, pygame.K_x, pygame.K_k)
LEFT_KEYS = (pygame.K_LEFT, pygame.K_a)
RIGHT_KEYS = (pygame.K_RIGHT, pygame.K_d)
RESTART_KEYS = (pygame.K_r,)
FULLSCREEN_KEYS = (pygame.K_f,)
MAIN_MENU_EXIT_KEYS = (pygame.K_ESCAPE,)
ESC_MENU_KEYS = (pygame.K_ESCAPE, pygame.K_p)  # Open the menu, and close it again.
ESC_MENU_UP_KEYS = (pygame.K_UP,)
ESC_MENU_DOWN_KEYS = (pygame.K_DOWN,)
ESC_MENU_CONFIRM_KEYS = (pygame.K_x, pygame.K_k, pygame.K_SPACE, pygame.K_RETURN)

# Display text constants.
DISPLAY_TEXT_COLOR = WHITE_COLOR
DISPLAY_TEXT_SIZE = 24
DISPLAY_TEXT_OUTLINE_COLOR = DARK_BROWN_COLOR
DISPLAY_TEXT_OUTLINE_WIDTH = 3

# Map constants.
MAP_FILE = "world.tmx"
SAVE_FILE = "save.sav"  # In the project root.
SAVE_KEY = "pyweek_carved_time_save"  # In the browser's local storage.

# Camera constants.
CLOCK_SCREEN_POS = (REAL_WIDTH // 2, REAL_HEIGHT // 2 + 2 * TILE_SIZE - 2)  # Clock center.

# Character constants.
CHARACTER_SIZE = 24
MAX_MOVE_SPEED = 100.0
MOVE_ACCEL = 1000.0
MOVE_DECEL = 600.0
JUMP_SPEED = 195.0
GRAVITY = 600.0
MAX_FALL_SPEED = 200.0
JUMP_BOOST_TIME = 0.2  # Reduced gravity at the start of each jump.
JUMP_BOOST_GRAVITY_SCALE = 0.5
COYOTE_TIME = 0.05
FREEZE_JUMP_TIME = 0.2  # After a freeze starts, a jump press still counts.
CELEBRATE_FRAME_TIME = 0.5

# Charge constants.
CHARGE_ANIMATION_TIME = 1.0  # Play every charging frame but the last.
CHARGE_HOLD_TIME = 0.5  # Hold the last charging frame before the glide.
CHARGE_FLASH_COUNT = 2  # Gold flashes of the clock during the hold.

# Clock constants.
CLOCK_SIZE = 2 * TILE_SIZE
CLOCK_TIME_STEP = 5.0  # Wait on each node before gliding to the next.
CLOCK_MOVE_SPEED = 10 * TILE_SIZE  # Glide between nodes, in pixels per second.
CLOCK_HAND_SIZE = 2 * TILE_SIZE  # One frame of the clock hand sprite sheet.
CLOCK_NODE_SIZE = 2 * TILE_SIZE  # One frame of the node sprite sheet.
CLOCK_PATH_WIDTH = 2
CLOCK_FLASH_ALPHA = 160
CLOCK_TICK_TIMES = (3.0, 4.0, 5.0)  # Into each wait, in seconds.

# Sound constants.
JUMP_SOUND_VOLUME = 0.4
LAUNCH_SOUND_VOLUME = 0.26
DEATH_SOUND_VOLUME = 0.45
PICKUP_SOUND_VOLUME = 0.6
CHARGE_SOUND_VOLUME = 0.33
TICK_SOUND_VOLUME = 0.6
CLOCK_MOVE_SOUND_VOLUME = 0.5

# Flow constants.
RESPAWN_HOLD = 1.0  # Hold everything still before play resumes.
DEATH_MESSAGE_TIME = 1.5  # Show the message before the character respawns.
DEATH_MESSAGE_MARGIN = 24  # From the bottom of the text to the bottom of the screen.
STAY_MESSAGE = "Charge the clock!"
FAR_MESSAGE = "Stay on screen!"
CRUSHED_MESSAGE = "Crushed!"
GOLD_MESSAGE = "Smashed!"
POWER_MESSAGE = "Bring a charge!"

# Checkpoint indicator constants.
CHECKPOINT_INDICATOR_SAFE_COLOR = (255, 255, 255)
CHECKPOINT_INDICATOR_SAFE_ALPHA = 110
CHECKPOINT_INDICATOR_UNSAFE_COLOR = (230, 40, 40)
CHECKPOINT_INDICATOR_UNSAFE_ALPHA = 200
CHECKPOINT_INDICATOR_CHARGING_ALPHA = 200

# Tutorial constants.
TUTORIAL_TEXT_COLOR = WHITE_COLOR
TUTORIAL_TEXT_SIZE = 8

# Esc menu constants.
ESC_MENU_POS = (16, 16)  # Top left of the border.
ESC_MENU_WIDTH = 150
ESC_MENU_BORDER_WIDTH = 2
ESC_MENU_ALPHA = 192  # Of the border and background.
ESC_MENU_TOP_PADDING = 20  # From the menu's top edge to the first option.
ESC_MENU_BOTTOM_PADDING = 5  # Below the last option's slot.
ESC_MENU_CURSOR_X = 15  # From the menu's left edge.
ESC_MENU_TEXT_X = 30  # From the menu's left edge.
ESC_MENU_OPTION_SPACING = 25
ESC_MENU_FONT_SIZE = 8
ESC_MENU_BORDER_COLOR = COPPER_COLOR
ESC_MENU_BG_COLOR = DARK_BROWN_COLOR
ESC_MENU_TEXT_COLOR = TAN_COLOR
ESC_MENU_SELECTED_COLOR = GOLD_COLOR

# Freeze constants.
FREEZE_ALPHA = 128
FREEZE_TINT_COLOR = (110, 150, 255)  # Multiplied into the character's frame.
MAX_FREEZE_OVERLAP = 0.5  # Fraction of the character inside solids that kills it.
DEATH_TINT_COLOR = (255, 90, 90)  # Replaces the freeze tint on a fatal leg.

# Preview constants.
PREVIEW_DOT_RADIUS = 1
PREVIEW_DOT_SPACING = 6
PREVIEW_DOT_ALPHA = 128
PREVIEW_CROSS_SIZE = 16
PREVIEW_CROSS_WIDTH = 2

# Tether constants.
TETHER_COLOR = (255, 232, 140)
TETHER_CORE_ALPHA = 100
TETHER_GLOW_ALPHA = 30
TETHER_CORE_WIDTH = 1
TETHER_GLOW_WIDTH = 3
TETHER_AMPLITUDE = 2.5  # Peak offset from the straight line, in pixels.
TETHER_WAVELENGTH = 16.0
TETHER_WAVE_SPEED = 60.0  # Pixels per second, from the clock toward the character.
TETHER_SEGMENT_LENGTH = 2

# Pickup constants.
PICKUP_FLOAT_AMPLITUDE = 2  # Peak offset from the tile center, in pixels.
PICKUP_FLOAT_PERIOD = 2.0  # One full rise and fall.
ENERGY_CARRY_HEIGHT = 2  # Gap between the character's top and a carried energy.
ENERGY_FOLLOW_RATE = 8.0  # Higher values trail the character more tightly.

# Launcher constants.
LAUNCHER_SPEED = 2 * JUMP_SPEED  # Upward launch speed.
LAUNCHER_COLLISION_SIZE = 12  # Square, centered on the tile.
