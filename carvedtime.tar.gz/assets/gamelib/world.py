import math

import pygame
import pytmx
from pytmx.util_pygame import load_pygame

from . import const
from . import data
from . import util


class Block(pygame.sprite.Sprite):

    def __init__(self, tile_x, tile_y, tile_image, has_collision, phasable, one_way):
        super().__init__()
        self.has_collision = has_collision
        self.phasable = phasable  # The frozen character may pass through it.
        self.one_way = one_way  # Solid only from above.
        x, y = util.tile_to_xy(tile_x, tile_y)
        self.image = tile_image
        self.rect = pygame.Rect(x, y, const.TILE_SIZE, const.TILE_SIZE)


class Clock(pygame.sprite.Sprite):

    def __init__(self, nodes, checkpoint_nodes, path, checkpoint_fn):
        super().__init__()
        self.nodes = [list(node) for node in nodes]  # Grid-aligned clock centers.
        self.checkpoint_nodes = checkpoint_nodes  # Node index per checkpoint number.
        self.path = path
        self.checkpoint_fn = checkpoint_fn

        # Path states.
        self.pos = list(self.nodes[0])
        self.node_index = 0
        self.target_index = 1
        self.gliding = False

        # Timers.
        self.wait_timer = 0.0
        self.glide_timer = 0.0
        self.glide_time = 0.0  # Duration of the current leg.

        # Flash states.
        self.flash_time = 0.0
        self.flash_timer = 0.0
        self.flash_count = 0

        # We carry the character by the rect's whole-pixel movement rather than
        # by pos, so a riding character stays flush with the clock's top.
        self.delta = [0, 0]

        self.image_base = pygame.image.load(data.filepath("clock.png")).convert_alpha()
        self.image_ss = pygame.image.load(data.filepath("clock_hand.png")).convert_alpha()
        self.image_hands = util.slice_sprite_sheet(
            self.image_ss, const.CLOCK_HAND_SIZE, const.CLOCK_HAND_SIZE
        )[0]
        self.image_flash = pygame.mask.from_surface(self.image_base).to_surface(
            setcolor=const.GOLD_COLOR, unsetcolor=None
        )
        self.image_flash.set_alpha(const.CLOCK_FLASH_ALPHA)
        self.image_rest = self.image_base.copy()  # As the clock arrives on a node.
        self.image_rest.blit(self.image_hands[0], (0, 0))
        self.image = self.image_base.copy()
        self.rect = pygame.Rect(0, 0, const.CLOCK_SIZE, const.CLOCK_SIZE)
        self.rect.center = self.pos
        self.path.highlight(self.node_index, self.target_index)

        self.move_sound = util.load_sound(
            "clock_move.ogg", const.CLOCK_MOVE_SOUND_VOLUME
        )
        self.tick_sound = util.load_sound("tick.ogg", const.TICK_SOUND_VOLUME)

    def update(self, dt):
        old_center = self.rect.center
        if self.gliding:
            self.update_glide(dt)
        else:
            self.update_wait(dt)
        self.rect.center = self.pos
        self.delta = [
            self.rect.centerx - old_center[0],
            self.rect.centery - old_center[1],
        ]
        self.draw_image()

    def update_wait(self, dt):
        old_wait_timer = self.wait_timer
        self.wait_timer = min(self.wait_timer + dt, const.CLOCK_TIME_STEP)
        self.play_ticks(old_wait_timer)
        if self.wait_timer < const.CLOCK_TIME_STEP:
            return

        if self.is_checkpoint_leg():
            self.checkpoint_fn(self.get_checkpoint())
        else:
            self.start_glide()

    def play_ticks(self, old_wait_timer):
        # We tick only as the timer crosses a mark, since it rests on the last
        # mark while the clock waits on a checkpoint.
        for tick_time in const.CLOCK_TICK_TIMES:
            if old_wait_timer < tick_time <= self.wait_timer:
                self.tick_sound.play()

    def start_glide(self):
        self.gliding = True
        self.glide_timer = 0.0
        start, target = self.get_next_leg()
        self.glide_time = math.dist(start, target) / const.CLOCK_MOVE_SPEED
        self.path.dim()
        self.move_sound.play(loops=-1)

    def stop_move_sound(self):
        self.move_sound.stop()

    def update_glide(self, dt):
        self.glide_timer = min(self.glide_timer + dt, self.glide_time)
        progress = self.get_glide_progress()
        start = self.nodes[self.node_index]
        target = self.nodes[self.target_index]
        self.pos = [
            start[0] + (target[0] - start[0]) * progress,
            start[1] + (target[1] - start[1]) * progress,
        ]
        if progress >= 1.0:
            self.arrive()

    def arrive(self):
        self.gliding = False
        self.stop_move_sound()
        self.wait_timer = 0.0
        self.node_index = self.target_index
        if self.is_at_end():
            return

        self.target_index += 1
        self.path.highlight(self.node_index, self.target_index)

    def reset_to_checkpoint(self, checkpoint):
        self.node_index = self.checkpoint_nodes[checkpoint]
        self.target_index = self.node_index + 1
        self.pos = list(self.nodes[self.node_index])
        self.gliding = False
        self.stop_move_sound()
        self.wait_timer = 0.0
        self.glide_timer = 0.0
        self.glide_time = 0.0
        self.stop_flash()
        self.delta = [0, 0]
        self.rect.center = self.pos
        self.path.highlight(self.node_index, self.target_index)
        self.draw_image()

    def is_at_end(self):
        return self.node_index == len(self.nodes) - 1

    def is_checkpoint_leg(self):
        # The game start is checkpoint 0, but its leg asks nothing of the character.
        return self.node_index > 0 and self.node_index in self.checkpoint_nodes

    def is_waiting_on_checkpoint(self):
        return self.is_checkpoint_leg() and not self.gliding

    def get_checkpoint(self):
        return self.checkpoint_nodes.index(self.node_index)

    def get_next_leg(self):
        return self.nodes[self.node_index], self.nodes[self.target_index]

    def get_glide_progress(self):
        # We report no progress before the first glide or after a reset, when a
        # character frozen by a death may still ask.
        if self.glide_time == 0.0:
            return 0.0
        return self.glide_timer / self.glide_time

    def start_flash(self, duration, count):
        self.flash_time = duration
        self.flash_timer = 0.0
        self.flash_count = count
        self.draw_image()

    def update_flash(self, dt):
        self.flash_timer = min(self.flash_timer + dt, self.flash_time)
        self.draw_image()

    def stop_flash(self):
        self.flash_timer = self.flash_time
        self.draw_image()

    def is_flash_on(self):
        if self.flash_timer >= self.flash_time:
            return False

        # Each flash is a gold half followed by a normal half.
        half = self.flash_time / (2 * self.flash_count)
        return int(self.flash_timer / half) % 2 == 0

    def draw_image(self):
        progress = self.wait_timer / const.CLOCK_TIME_STEP

        # The last frame repeats the first, so the hand reaches it only when the wait
        # is complete.
        frame = int(progress * (len(self.image_hands) - 1))
        self.image = self.image_base.copy()
        self.image.blit(self.image_hands[frame], (0, 0))
        if self.is_flash_on():
            self.image.blit(self.image_flash, (0, 0))


class ClockPath:

    def __init__(self, nodes, checkpoint_nodes, camera_mgr):
        self.nodes = [list(node) for node in nodes]
        self.checkpoint_nodes = checkpoint_nodes
        self.camera_mgr = camera_mgr
        self.next_leg = None  # Node indices of the highlighted leg.

        # Rows are regular and checkpoint nodes, columns inactive and active.
        self.image_ss = pygame.image.load(data.filepath("nodes.png")).convert_alpha()
        self.images = util.slice_sprite_sheet(
            self.image_ss, const.CLOCK_NODE_SIZE, const.CLOCK_NODE_SIZE
        )

    def highlight(self, start_index, end_index):
        self.next_leg = (start_index, end_index)

    def dim(self):
        self.next_leg = None

    def draw(self, surface):
        # We draw to the screen each frame because a cached image of a path that
        # spans the map could grow too large. Nodes go last to sit atop their legs.
        for leg in self._legs():
            self._draw_leg(surface, leg, const.MID_BROWN_COLOR)
        if self.next_leg:
            self._draw_leg(surface, self.next_leg, self._get_active_leg_color())
        for index in range(len(self.nodes)):
            self._draw_node(surface, index)

    def _legs(self):
        return [(index, index + 1) for index in range(len(self.nodes) - 1)]

    def _get_active_leg_color(self):
        if self._is_checkpoint(self.next_leg[1]):
            return const.GOLD_COLOR
        return const.WHITE_COLOR

    def _is_checkpoint(self, index):
        # The game start is checkpoint 0, but we draw it as a regular node.
        return index > 0 and index in self.checkpoint_nodes

    def _is_active(self, index):
        return self.next_leg is not None and index == self.next_leg[1]

    def _draw_leg(self, surface, leg, color):
        start = self._get_leg_end(leg[0])
        end = self._get_leg_end(leg[1])
        pygame.draw.line(surface, color, start, end, const.CLOCK_PATH_WIDTH)

    def _get_leg_end(self, index):
        x, y = self.camera_mgr.to_screen_pos(self.nodes[index])

        # We shift legs one pixel up and left to line up with the node sprites.
        return x - 1, y - 1

    def _draw_node(self, surface, index):
        row = 1 if self._is_checkpoint(index) else 0
        column = 1 if self._is_active(index) else 0
        image = self.images[row][column]
        rect = image.get_rect(center=self.camera_mgr.to_screen_pos(self.nodes[index]))
        surface.blit(image, rect)


class Pickup(pygame.sprite.Sprite):

    def __init__(self, tile_x, tile_y, image, checkpoint):
        super().__init__()
        self.tile_x = tile_x
        self.tile_y = tile_y
        self.checkpoint = checkpoint  # The last checkpoint before this pickup.
        x, y = util.tile_to_xy(tile_x, tile_y)
        half_tile = const.TILE_SIZE / 2
        self.home_pos = [x + half_tile, y + half_tile]
        self.base_pos = list(self.home_pos)  # The center the pickup floats around.
        self.pos = list(self.base_pos)
        self.float_timer = 0.0

        self.image = image
        self.rect = self.image.get_rect()

        # We collide with the opaque art only, so a pickup sharing a tile with a
        # platform cannot be picked up from on top of the platform.
        self.collision_rect = self.image.get_bounding_rect()
        self.collision_offset = self.collision_rect.topleft  # From the image's corner.
        self._sync_rects()

    def _sync_rects(self):
        self.rect.center = (round(self.pos[0]), round(self.pos[1]))
        self.collision_rect.topleft = (
            self.rect.left + self.collision_offset[0],
            self.rect.top + self.collision_offset[1],
        )

    def update(self, dt):
        self.float_timer = (self.float_timer + dt) % const.PICKUP_FLOAT_PERIOD
        phase = 2 * math.pi * self.float_timer / const.PICKUP_FLOAT_PERIOD
        self.pos = [
            self.base_pos[0],
            self.base_pos[1] + const.PICKUP_FLOAT_AMPLITUDE * math.sin(phase),
        ]
        self._sync_rects()

    def pick_up(self, carrier):
        self.kill()

    def reset(self):
        self.base_pos = list(self.home_pos)
        self.pos = list(self.base_pos)
        self.float_timer = 0.0
        self._sync_rects()


class Energy(Pickup):

    def __init__(self, tile_x, tile_y, checkpoint):
        image = pygame.image.load(data.filepath("energy.png")).convert_alpha()
        super().__init__(tile_x, tile_y, image, checkpoint)
        self.carrier = None

    def update(self, dt):
        if self.carrier is not None:
            self.follow_carrier(dt)
        super().update(dt)

    def follow_carrier(self, dt):
        target = [
            self.carrier.pos[0],
            self.carrier.rect.top - const.ENERGY_CARRY_HEIGHT - self.rect.height / 2,
        ]

        # We ease exponentially so the trail feels the same at any frame rate.
        ease = 1 - math.exp(-const.ENERGY_FOLLOW_RATE * dt)
        self.base_pos[0] += (target[0] - self.base_pos[0]) * ease
        self.base_pos[1] += (target[1] - self.base_pos[1]) * ease

    def pick_up(self, carrier):
        self.carrier = carrier

    def reset(self):
        super().reset()
        self.carrier = None


class Launcher(pygame.sprite.Sprite):

    def __init__(self, tile_x, tile_y, image):
        super().__init__()
        x, y = util.tile_to_xy(tile_x, tile_y)
        self.image = image
        self.rect = pygame.Rect(x, y, const.TILE_SIZE, const.TILE_SIZE)
        self.collision_rect = pygame.Rect(
            0, 0, const.LAUNCHER_COLLISION_SIZE, const.LAUNCHER_COLLISION_SIZE
        )
        self.collision_rect.center = self.rect.center
        self.touching = False  # The character overlapped it last frame.

    def update(self, dt):
        pass


class GameObjectFactory:

    @staticmethod
    def create_clock(obj_data, world_mgr):
        try:
            nodes = obj_data.points
        except AttributeError as error:
            raise ValueError(
                f"Clock object {obj_data.id} must be a polyline"
            ) from error
        if obj_data.closed:
            raise ValueError(
                f"Clock object {obj_data.id} must be an open polyline, not a polygon"
            )
        GameObjectFactory.check_distinct_nodes(obj_data, nodes)
        checkpoint_nodes = GameObjectFactory.find_checkpoint_nodes(
            obj_data, nodes, world_mgr.checkpoint_points
        )
        path = ClockPath(nodes, checkpoint_nodes, world_mgr.camera_mgr)
        return Clock(
            nodes,
            checkpoint_nodes,
            path,
            checkpoint_fn=world_mgr.checkpoint_fn,
        )

    @staticmethod
    def check_distinct_nodes(obj_data, nodes):
        # A leg of zero length has no glide time at a constant speed.
        for start, end in zip(nodes, nodes[1:]):
            if tuple(start) == tuple(end):
                raise ValueError(
                    f"Clock object {obj_data.id} repeats the node at {tuple(start)}"
                )

    @staticmethod
    def find_checkpoint_nodes(obj_data, nodes, checkpoint_points):
        node_positions = [tuple(node) for node in nodes]
        last_index = len(nodes) - 1
        checkpoint_nodes = {0}  # The game start.
        for point in checkpoint_points:
            if point not in node_positions:
                raise ValueError(
                    f"Checkpoint at {point} is not on a node of clock {obj_data.id}"
                )
            node_index = node_positions.index(point)
            if node_index in (0, last_index):
                raise ValueError(
                    f"Checkpoint at {point} must not be on the first or last node"
                )
            checkpoint_nodes.add(node_index)
        return sorted(checkpoint_nodes)

    @staticmethod
    def create_pickup(obj_data):
        tile_x, tile_y = util.xy_to_tile(obj_data.x, obj_data.y)
        checkpoint = obj_data.properties.get("checkpoint")
        if not isinstance(checkpoint, int):
            raise ValueError(
                f"Pickup object {obj_data.id} needs an int 'checkpoint' property"
            )

        pickup_type = (obj_data.type or "").lower()
        if pickup_type == "energy":
            return Energy(tile_x, tile_y, checkpoint)
        raise ValueError(
            f"Pickup object {obj_data.id} has unknown type '{obj_data.type}'"
        )

    @staticmethod
    def create_launcher(obj_data):
        # We take the image pytmx sliced from the tile sprite sheet for the gid.
        if not obj_data.gid:
            raise ValueError(f"Launcher object {obj_data.id} must be a tile object")
        tile_x, tile_y = util.xy_to_tile(obj_data.x, obj_data.y)
        return Launcher(tile_x, tile_y, obj_data.image)


class WorldManager:

    def __init__(self, camera_mgr, checkpoint_fn, finish_fn):
        self.camera_mgr = camera_mgr
        self.checkpoint_fn = checkpoint_fn
        self.finish_fn = finish_fn
        self.filename = data.filepath(const.MAP_FILE)
        self.tmx_data = load_pygame(self.filename)

        self.checkpoint_points = self.find_checkpoint_points()
        self.create_blocks()
        self.create_launchers()
        self.create_clock()
        self.create_pickups()
        self.validate_pickups()
        self.pickup_sound = util.load_sound("pickup.ogg", const.PICKUP_SOUND_VOLUME)

    def find_checkpoint_points(self):
        checkpoints_layer = self._get_layer("Checkpoints", pytmx.TiledObjectGroup)
        return [(obj.x, obj.y) for obj in checkpoints_layer]

    def create_blocks(self):
        self.blocks = {}  # Keyed by (tile_x, tile_y).
        blocks_layer = self._get_layer("Blocks", pytmx.TiledTileLayer)
        self.add_blocks(blocks_layer, phasable=True)
        gold_blocks_layer = self._find_layer("GoldBlocks", pytmx.TiledTileLayer)
        if gold_blocks_layer is not None:
            self.add_blocks(gold_blocks_layer, phasable=False)
        platforms_layer = self._find_layer("Platforms", pytmx.TiledTileLayer)
        if platforms_layer is not None:
            self.add_blocks(platforms_layer, phasable=True, one_way=True)

    def add_blocks(self, layer, phasable, one_way=False):
        for tile_x, tile_y, gid in layer:
            if gid == 0:
                continue  # Empty tile.
            if (tile_x, tile_y) in self.blocks:
                raise ValueError(
                    f"TMX file {self.filename} has two blocks at tile "
                    f"({tile_x}, {tile_y})"
                )

            tile_props = self.tmx_data.get_tile_properties_by_gid(gid) or {}
            tile_image = self.tmx_data.get_tile_image_by_gid(gid)
            has_collision = not tile_props.get("nocollision")
            if not has_collision and (one_way or not phasable):
                raise ValueError(
                    f"TMX file {self.filename} has a nocollision tile at "
                    f"({tile_x}, {tile_y}) in layer '{layer.name}'"
                )
            self.blocks[(tile_x, tile_y)] = Block(
                tile_x, tile_y, tile_image, has_collision, phasable, one_way
            )

    def create_launchers(self):
        self.launchers = pygame.sprite.Group()
        launchers_layer = self._find_layer("Launchers", pytmx.TiledObjectGroup)
        if launchers_layer is None:
            return
        for obj_data in launchers_layer:
            self.launchers.add(GameObjectFactory.create_launcher(obj_data))

    def create_clock(self):
        clocks_layer = self._get_layer("Clocks", pytmx.TiledObjectGroup)
        if len(clocks_layer) != 1:
            raise ValueError(f"TMX file {self.filename} needs exactly one clock")
        self.clock = GameObjectFactory.create_clock(clocks_layer[0], self)

    def create_pickups(self):
        pickups_layer = self._get_layer("Pickups", pytmx.TiledObjectGroup)

        # We keep every pickup here so a respawn can restore collected ones.
        self.pickups = [
            GameObjectFactory.create_pickup(obj_data) for obj_data in pickups_layer
        ]
        self.map_pickups = pygame.sprite.Group(self.pickups)  # Not yet picked up.

        # We hold the carried energy apart from map_pickups so it draws above
        # the character.
        self.carried = pygame.sprite.GroupSingle()

    def validate_pickups(self):
        checkpoint_count = self.get_checkpoint_count()
        for obj in self.pickups:
            if not 0 <= obj.checkpoint < checkpoint_count:
                raise ValueError(
                    f"TMX file {self.filename} tags a pickup with unknown "
                    f"checkpoint {obj.checkpoint}"
                )

    def _get_layer(self, name, layer_type):
        layer = self._find_layer(name, layer_type)
        if layer is None:
            raise ValueError(f"TMX file {self.filename} is missing a '{name}' layer")
        return layer

    def _find_layer(self, name, layer_type):
        for layer in self.tmx_data.visible_layers:
            if isinstance(layer, layer_type) and layer.name == name:
                return layer
        return None

    def reset_to_checkpoint(self, checkpoint):
        self.clock.reset_to_checkpoint(checkpoint)
        self.carried.empty()
        for obj in self.launchers:
            obj.touching = False

        # Each pickup belongs to the stretch after its checkpoint, and we assume
        # the character collected every pickup before the one it respawns at.
        for obj in self.pickups:
            if obj.checkpoint >= checkpoint:
                obj.reset()
                self.map_pickups.add(obj)
            else:
                obj.kill()

    def get_checkpoint_count(self):
        return len(self.clock.checkpoint_nodes)

    def draw(self, surface):
        self.camera_mgr.draw(surface, self.map_pickups)
        self.camera_mgr.draw(surface, self.launchers)
        self.camera_mgr.draw(
            surface, self.get_blocks_in_rect(self.camera_mgr.view_rect)
        )
        self.clock.path.draw(surface)
        self.camera_mgr.draw(surface, [self.clock])

    def draw_carried(self, surface):
        self.camera_mgr.draw(surface, self.carried)

    def get_blocks_in_rect(self, rect):
        left, top = util.xy_to_tile(rect.left, rect.top)
        right, bottom = util.xy_to_tile(rect.right - 1, rect.bottom - 1)
        blocks = []
        for tile_y in range(top, bottom + 1):
            for tile_x in range(left, right + 1):
                block = self.blocks.get((tile_x, tile_y))
                if block is not None:
                    blocks.append(block)
        return blocks

    def get_solid_blocks(self, rect):
        return [
            block
            for block in self.get_blocks_in_rect(rect)
            if block.has_collision and not block.one_way
        ]

    def get_platforms(self, rect):
        return [block for block in self.get_blocks_in_rect(rect) if block.one_way]

    def get_gold_blocks(self, rect):
        return [block for block in self.get_blocks_in_rect(rect) if not block.phasable]

    def get_collision_objects(self, rect):
        return self.get_solid_blocks(rect) + [self.clock]

    def is_solid_at_xy(self, x, y):
        block = self.blocks.get(util.xy_to_tile(x, y))
        return block is not None and block.has_collision and not block.one_way

    def is_platform_top_at_xy(self, x, y):
        # We count only the top pixel, so a character partway inside a platform
        # does not stand on it.
        top_depth = 1
        block = self.blocks.get(util.xy_to_tile(x, y))
        if block is None or not block.one_way:
            return False
        return y - block.rect.top <= top_depth

    def update(self, dt, character):
        self.clock.update(dt)
        self.map_pickups.update(dt)
        self.update_clock_contacts(character)
        self.update_launcher_contacts(character)

        # We move the carried energy once the character has settled, so it
        # trails the character's final position for the frame.
        self.carried.update(dt)
        self.update_pickup_contacts(character)

        # We report the finish only after the character lands, so a crush on the
        # final landing still kills it.
        if self.clock.is_at_end():
            self.finish_fn()

    def update_clock_contacts(self, character):
        # We follow after the clock moves so the frozen character never lags a frame.
        if character.frozen:
            character.follow(self.clock)
            return

        if character.grounded and character.ridden_clock is self.clock:
            character.ride(self.clock.delta)
        if character.collision_rect.colliderect(self.clock.rect):
            character.push_out_of(self.clock)

    def update_launcher_contacts(self, character):
        if character.frozen or character.charging or character.celebrating:
            return

        # We launch only on the first frame of a touch, so the sound plays once.
        for obj in self.launchers:
            touching = character.collision_rect.colliderect(obj.collision_rect)
            if touching and not obj.touching:
                character.launch()
            obj.touching = touching

    def update_pickup_contacts(self, character):
        if character.frozen:
            return

        for obj in list(self.map_pickups):
            if not self.can_pick_up(obj):
                continue
            if character.collision_rect.colliderect(obj.collision_rect):
                self.pick_up(obj, character)

    def can_pick_up(self, obj):
        # The character carries one energy at a time.
        if isinstance(obj, Energy):
            return not self.is_carrying_energy()
        return True

    def pick_up(self, obj, character):
        obj.pick_up(character)
        if isinstance(obj, Energy):
            self.map_pickups.remove(obj)
            self.carried.add(obj)
            self.pickup_sound.play()

    def is_carrying_energy(self):
        return self.carried.sprite is not None

    def consume_energy(self):
        self.carried.sprite.kill()
