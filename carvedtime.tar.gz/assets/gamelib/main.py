'''Game main module.

Contains the entry point used by the run_game.py script.

Feel free to put all your game code here, or in other modules in this "gamelib"
package.
'''

import pygame

from . import const
from . import game

async def main():
    buffer = const.WEB_AUDIO_BUFFER if const.IS_WEB else const.AUDIO_BUFFER
    try:
        pygame.mixer.pre_init(44100, -16, 1, buffer)
    except pygame.error:
        pass
    pygame.init()
    await game.GameWindow().run()
