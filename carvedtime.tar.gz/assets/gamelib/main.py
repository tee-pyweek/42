'''Game main module.

Contains the entry point used by the run_game.py script.

Feel free to put all your game code here, or in other modules in this "gamelib"
package.
'''

import pygame

from . import game

async def main():
    try:
        pygame.mixer.pre_init(44100, -16, 1, 512)
    except pygame.error:
        pass
    pygame.init()
    await game.GameWindow().run()
