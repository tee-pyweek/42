import asyncio
import sys

import pygame

from . import const
from . import data
from . import ptext
from . import util


ESC_MENU_OPTIONS = [
    # label, action
    ("Return", "return"),
    ("To last checkpoint", "restart"),
    ("New game", "new_game"),
    ("Toggle music", "toggle_music"),
    ("Fullscreen", "toggle_fullscreen"),
    ("Exit game", "exit"),
]
ESC_MENU_STAY_OPEN_ACTIONS = ("toggle_fullscreen",)
ESC_MENU_DESKTOP_ONLY_ACTIONS = ("exit",)  # A page cannot close its own tab.


# fmt: off
TUTORIAL_TEXTS = [
    # tile_x, tile_y, text
    (10,  4, "Yes! You are alive!\nYou have borrowed time from the clock!"),
    (10,  6, "But now your timelines are intertwined!\nYou can move only between\neach five-second beat"),
    (14,  13.5, "ESC for menu, R to restart from checkpoint,\nWASD/Arrows to move,\nX/K/Space to jump,\nbut don't fall off!"),
    (22,  5, "The trail ahead of you\nshows you where you\nwill be after each beat"),
    (32,  4, "Collect every charge\nalong the way!\nYou must bring it to\npower checkpoints!"),
    (32,  11.5, "Never forget that you\nmove with the clock!"),
    (40,  4.5, "Charge the clock at\nthis power checkpoint!\nYou must have the charge\nand be standing on top of the clock\nat the end of countdown!\n\nIf you can't, you respawn\nat the last checkpoint!"),
    (50,  11.5, "The clock move gets you through walls,\nbut don't get crushed!\n\nTime your jump!"),
    (63,  4.5, "You can jump on platforms from below\nbut you cannot drop from them"),
    (73,  8, "Good luck!"),
    (16,  45, "Golden blocks cannot\nbe phased through"),
]
# fmt: on

END_TEXT = (9, 85.5, "The end!\nThank you\nfor playing!")


class MainMenu:

    def __init__(self, real_screen, toggle_fullscreen_fn, start_music_fn):
        self.real_screen = real_screen
        self.toggle_fullscreen_fn = toggle_fullscreen_fn
        self.start_music_fn = start_music_fn
        self.screen = pygame.Surface((const.REAL_WIDTH, const.REAL_HEIGHT))
        self.clock = pygame.time.Clock()

        # Screen states.
        self.done = False

        intro = pygame.image.load(data.filepath("intro.png")).convert()
        self.screen.blit(intro, (0, 0))

    async def loop(self):
        self.done = False

        # Drop key presses from before the menu opened, such as one pressed while
        # the web page loads, so they do not skip the menu.
        pygame.event.clear()
        while not self.done:
            self.handle_events()
            self.clock.tick(const.FPS)
            pygame.transform.scale(
                self.screen, (const.WIDTH, const.HEIGHT), self.real_screen
            )
            pygame.display.flip()

            # Yield to the browser once per frame, which pygbag needs to keep the
            # page responsive. On the desktop this returns immediately.
            await asyncio.sleep(0)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and const.IS_WEB:
                # We start the music on a click in the browser, which unlocks audio
                # without leaving the title screen.
                self.start_music_fn()
            elif event.type != pygame.KEYDOWN:
                continue
            elif event.key in const.MAIN_MENU_EXIT_KEYS:
                # We ignore exit on the web, where a page cannot close its own tab.
                if not const.IS_WEB:
                    sys.exit()
            elif event.key in const.FULLSCREEN_KEYS:
                self.toggle_fullscreen_fn()
            else:
                self.done = True


class EscMenu:

    def __init__(self, screen):
        self.screen = screen
        self.visible = False
        self.selected_option = 0
        self.options = self._get_platform_options()
        self.rect = pygame.Rect(
            const.ESC_MENU_POS[0] + const.ESC_MENU_BORDER_WIDTH,
            const.ESC_MENU_POS[1] + const.ESC_MENU_BORDER_WIDTH,
            const.ESC_MENU_WIDTH,
            const.ESC_MENU_TOP_PADDING
            + len(self.options) * const.ESC_MENU_OPTION_SPACING
            + const.ESC_MENU_BOTTOM_PADDING,
        )
        self.image_panel = self._create_panel_image()

    def _get_platform_options(self):
        if not const.IS_WEB:
            return ESC_MENU_OPTIONS
        return [
            (label, action)
            for label, action in ESC_MENU_OPTIONS
            if action not in ESC_MENU_DESKTOP_ONLY_ACTIONS
        ]

    def _create_panel_image(self):
        # We draw the border and background opaque and fade the panel as a whole,
        # so the border does not show through the background.
        border = 2 * const.ESC_MENU_BORDER_WIDTH
        image = pygame.Surface(self.rect.inflate(border, border).size)
        image.fill(const.ESC_MENU_BORDER_COLOR)
        inner = pygame.Rect(
            (const.ESC_MENU_BORDER_WIDTH, const.ESC_MENU_BORDER_WIDTH), self.rect.size
        )
        image.fill(const.ESC_MENU_BG_COLOR, inner)
        image.set_alpha(const.ESC_MENU_ALPHA)
        return image

    def show(self):
        self.visible = True
        self.selected_option = 0

    def hide(self):
        self.visible = False

    def handle_input(self, event):
        if not self.visible or event.type != pygame.KEYDOWN:
            return None

        if event.key in const.ESC_MENU_KEYS:
            self.hide()
            return "return"
        if event.key in const.ESC_MENU_UP_KEYS:
            self.selected_option = (self.selected_option - 1) % len(self.options)
        elif event.key in const.ESC_MENU_DOWN_KEYS:
            self.selected_option = (self.selected_option + 1) % len(self.options)
        elif event.key in const.ESC_MENU_CONFIRM_KEYS:
            action = self.options[self.selected_option][1]
            if action not in ESC_MENU_STAY_OPEN_ACTIONS:
                self.hide()
            return action
        return None

    def draw(self):
        if not self.visible:
            return

        self.screen.blit(self.image_panel, const.ESC_MENU_POS)
        for index, (label, _) in enumerate(self.options):
            self._draw_option(index, label)

    def _draw_option(self, index, label):
        y = (
            self.rect.top
            + const.ESC_MENU_TOP_PADDING
            + index * const.ESC_MENU_OPTION_SPACING
        )
        selected = index == self.selected_option
        color = const.ESC_MENU_SELECTED_COLOR if selected else const.ESC_MENU_TEXT_COLOR
        if selected:
            self._draw_text(">", const.ESC_MENU_CURSOR_X, y, color)
        self._draw_text(label, const.ESC_MENU_TEXT_X, y, color)

    def _draw_text(self, text, offset_x, y, color):
        ptext.draw(
            text,
            (self.rect.left + offset_x, y),
            fontname=const.FONT_MAIN,
            fontsize=const.ESC_MENU_FONT_SIZE,
            antialias=False,
            color=color,
            surf=self.screen,
        )


class TutorialManager:

    def __init__(self, camera_mgr):
        self.camera_mgr = camera_mgr
        self.sprites = pygame.sprite.Group()
        for tile_x, tile_y, text in TUTORIAL_TEXTS:
            self.sprites.add(self._create_tutorial_text(tile_x, tile_y, text))
        self.sprites.add(self._create_end_text(*END_TEXT))

    def draw(self, surface):
        self.camera_mgr.draw(surface, self.sprites)

    def _create_tutorial_text(self, tile_x, tile_y, text):
        return util.create_text(
            text,
            self._get_tile_center(tile_x, tile_y),
            color=const.TUTORIAL_TEXT_COLOR,
            fontsize=const.TUTORIAL_TEXT_SIZE,
            anchor=(0.5, 0.5),
        )

    def _create_end_text(self, tile_x, tile_y, text):
        return util.create_display_text(
            text, self._get_tile_center(tile_x, tile_y), anchor=(0.5, 0.5)
        )

    def _get_tile_center(self, tile_x, tile_y):
        x, y = util.tile_to_xy(tile_x, tile_y)
        half_tile = const.TILE_SIZE / 2
        return (x + half_tile, y + half_tile)
