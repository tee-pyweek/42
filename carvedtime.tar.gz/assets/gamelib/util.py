import math
import platform

import pygame

from . import ptext
from . import const
from . import data


def xy_to_tile(x, y):
    return int(x // const.TILE_SIZE), int(y // const.TILE_SIZE)


def tile_to_xy(tile_x, tile_y):
    return tile_x * const.TILE_SIZE, tile_y * const.TILE_SIZE


def get_normalized_vector(source, target):
    vx = target[0] - source[0]
    vy = target[1] - source[1]
    norm = math.hypot(vx, vy)
    if norm < 1e-6:
        return (0.0, 0.0)
    return (vx / norm, vy / norm)


def get_point_along(start, end, fraction):
    return [
        start[0] + (end[0] - start[0]) * fraction,
        start[1] + (end[1] - start[1]) * fraction,
    ]


def distance(p1, p2):
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])


def move_towards(current, target, max_delta):
    if current < target:
        return min(current + max_delta, target)
    elif current > target:
        return max(current - max_delta, target)
    else:
        return target


def slice_sprite_sheet(image, tile_size_x, tile_size_y):
    sheet_width, sheet_height = image.get_size()
    width = int(sheet_width / tile_size_x)
    height = int(sheet_height / tile_size_y)
    images = [[None for j in range(width)] for i in range(height)]
    for i in range(height):
        for j in range(width):
            images[i][j] = image.subsurface(
                j * tile_size_x, i * tile_size_y, tile_size_x, tile_size_y
            )
    return images


def tint(image, color, alpha):
    # We blit onto a plain surface because copying an Animation yields an
    # uninitialized Animation whose set_alpha fails.
    tinted = pygame.Surface(image.get_size(), pygame.SRCALPHA)
    tinted.blit(image, (0, 0))
    tinted.fill(color, special_flags=pygame.BLEND_RGB_MULT)
    tinted.set_alpha(alpha)
    return tinted


def load_sound(filename, volume):
    try:
        sound = pygame.mixer.Sound(data.filepath(filename))
    except pygame.error:
        return SilentSound()
    sound.set_volume(volume)
    return sound


def pause_sounds():
    try:
        pygame.mixer.pause()
    except pygame.error:
        pass


def unpause_sounds():
    try:
        pygame.mixer.unpause()
    except pygame.error:
        pass


class SilentSound:

    def play(self, loops=0):
        pass

    def stop(self):
        pass


def create_text(
    text,
    pos,
    color=(154, 159, 135),
    fontsize=8,
    anchor=None,
    fontname=const.FONT_MAIN,
    outline_color=None,
    outline_width=None,
):
    anchor = anchor or (0, 0)
    style = {
        "fontname": fontname,
        "fontsize": fontsize,
        "color": color,
        "ocolor": outline_color,
        "owidth": outline_width,
        "antialias": False,
    }
    sprite = pygame.sprite.Sprite()
    sprite.image = _render_lines(text.split("\n"), style, anchor[0])
    sprite.rect = sprite.image.get_rect()
    sprite.rect.topleft = (
        round(pos[0] - anchor[0] * sprite.rect.width),
        round(pos[1] - anchor[1] * sprite.rect.height),
    )
    return sprite


def create_display_text(text, pos, anchor):
    return create_text(
        text,
        pos,
        color=const.DISPLAY_TEXT_COLOR,
        fontsize=const.DISPLAY_TEXT_SIZE,
        anchor=anchor,
        fontname=const.FONT_DISPLAY,
        outline_color=const.DISPLAY_TEXT_OUTLINE_COLOR,
        outline_width=const.DISPLAY_TEXT_OUTLINE_WIDTH,
    )


def _render_lines(lines, style, align):
    # We stack the lines ourselves because ptext sizes a multiline surface from the
    # font's reported height, which cuts off the last line of the pixel font.
    line_images = [ptext.getsurf(line, **style) for line in lines]
    if len(line_images) == 1:
        return line_images[0]

    line_step = line_images[0].get_height() + const.TEXT_LINE_GAP
    width = max(line_image.get_width() for line_image in line_images)
    height = line_step * (len(line_images) - 1) + line_images[-1].get_height()
    image = pygame.Surface((width, height), pygame.SRCALPHA)
    for i, line_image in enumerate(line_images):
        x = round(align * (width - line_image.get_width()))
        image.blit(line_image, (x, i * line_step))
    return image


class Animation(pygame.surface.Surface):

    def __init__(self, frames, interval, loop=True, paused=False, callback_fn=None):
        pygame.surface.Surface.__init__(self, frames[0].get_size(), pygame.SRCALPHA, 32)
        self.frames = frames
        self.loop = loop
        self.finished = False
        self.callback_fn = callback_fn
        if isinstance(interval, list):
            self.interval = interval
        else:
            self.interval = [interval] * len(self.frames)
        self.start()
        if paused:
            self.pause()

    def clear(self):
        self.fill((0, 0, 0, 0))

    def set_alpha(self, alpha):
        for image in self.frames:
            image.set_alpha(alpha)

    def pause(self):
        self.paused = True

    def start(self):
        self.paused = False
        self.current_frame = 0
        self.timer = self.interval[self.current_frame]
        self.clear()
        self.blit(self.frames[self.current_frame], (0, 0))

    def reset(self):
        self.finished = False
        self.start()

    def update(self, dt):
        if self.paused or self.finished:
            return None
        self.timer -= dt
        if self.timer <= 0:
            self.current_frame += 1
            if self.current_frame >= len(self.frames):
                if self.callback_fn:
                    self.callback_fn()
                if self.loop:
                    self.current_frame = 0
                else:
                    self.finished = True
                    return None
            self.timer = self.interval[self.current_frame]
            self.clear()
            self.blit(self.frames[self.current_frame], (0, 0))
            return self.current_frame
        return None


def load_checkpoint(checkpoint_count):
    try:
        checkpoint = int(_read_save())
    except (OSError, ValueError, TypeError):
        return 0

    # We start a new game rather than crash when the map changed since saving.
    if not 0 <= checkpoint < checkpoint_count:
        return 0
    return checkpoint


def write_checkpoint(checkpoint):
    try:
        _write_save(f"{checkpoint}\n")
    except OSError:
        # We keep playing without saving progress rather than crash.
        pass


def _read_save():
    # We keep the save in local storage on the web, because the page's file system
    # is wiped on every reload. A missing key reads as None.
    if const.IS_WEB:
        return platform.window.localStorage.getItem(const.SAVE_KEY)
    with open(data.rootpath(const.SAVE_FILE)) as save_file:
        return save_file.read()


def _write_save(text):
    if const.IS_WEB:
        platform.window.localStorage.setItem(const.SAVE_KEY, text)
        return
    with open(data.rootpath(const.SAVE_FILE), "w") as save_file:
        save_file.write(text)


def cap_web_canvas_size():
    # We keep the page from stretching the game past the size it was drawn for. The
    # template lifts this cap while the page is fullscreen.
    style = platform.window.canvas.style
    style.maxWidth = f"{const.WIDTH}px"
    style.maxHeight = f"{const.HEIGHT}px"


def toggle_web_fullscreen():
    document = platform.window.document

    # We compare against None because pygbag cannot test a browser element for
    # truth, and raises a TypeError instead.
    if document.fullscreenElement is not None:
        document.exitFullscreen()
        return
    document.documentElement.requestFullscreen()
