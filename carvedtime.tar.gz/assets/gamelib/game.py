import asyncio
import math
import sys

import pygame

from . import const
from . import data
from . import ui
from . import util
from . import world


class GameWindow:

    def __init__(self):
        pygame.display.set_caption("Carved Time")
        self.screen = pygame.display.set_mode((const.WIDTH, const.HEIGHT))
        if const.IS_WEB:
            util.cap_web_canvas_size()

        self.music_started = False
        try:
            pygame.mixer.init()
            pygame.mixer.music.load(data.filepath("Loopster.ogg"))
        except pygame.error:
            pass

        # We hold the music back on the web until the first key press leaves the
        # main menu, because browsers refuse to play audio before the player
        # interacts with the page.
        if not const.IS_WEB:
            self.start_music()

        self.running_game = Game(self.screen)
        self.intro = ui.MainMenu(
            self.screen,
            toggle_fullscreen_fn=self.running_game.toggle_fullscreen,
            start_music_fn=self.start_music,
        )

    async def run(self):
        while True:
            await self.intro.loop()
            self.start_music()
            await self.running_game.loop()
            self.running_game.resume()

    def start_music(self):
        if self.music_started:
            return

        self.music_started = True
        try:
            pygame.mixer.music.play(-1)
        except pygame.error:
            pass


class Game:

    def __init__(self, screen):
        self.real_screen = screen
        self.screen = pygame.Surface((const.REAL_WIDTH, const.REAL_HEIGHT))
        self.clock = pygame.time.Clock()
        self.bg = pygame.image.load(data.filepath("bg.png"))
        self.fg = pygame.image.load(data.filepath("fg.png"))

        self.camera_mgr = CameraManager()
        self.tutorial_mgr = ui.TutorialManager(self.camera_mgr)
        self.world_mgr = world.WorldManager(
            self.camera_mgr,
            checkpoint_fn=self.reach_checkpoint,
            finish_fn=self.finish,
        )
        self.character = Character(
            self.world_mgr, self.camera_mgr, die_fn=self.die
        )
        self.character_con = pygame.sprite.Group(self.character)
        self.preview_mgr = PreviewManager(
            self.character, self.world_mgr, self.camera_mgr
        )
        self.tether_mgr = TetherManager(
            self.character, self.world_mgr, self.camera_mgr
        )
        self.checkpoint_indicator_mgr = CheckpointIndicatorManager(
            self.character, self.world_mgr, self.camera_mgr
        )
        self.flow_mgr = FlowManager(
            self.world_mgr,
            self.character,
            respawn_fn=self.respawn,
        )
        self.esc_menu = ui.EscMenu(self.screen)

        # Screen states.
        self.fullscreen = False
        self.done = False

        self.music_enabled = True

    async def loop(self):
        # We reset the clock so time spent in the main menu does not count as a frame.
        self.clock.tick()
        while not self.done:
            self.handle_events()
            self.screen.blit(self.bg, (0, 0))

            dt = min(self.clock.tick(const.FPS) / 1000.0, const.MAX_DT)

            if not self.esc_menu.visible:
                self.update(dt)

            self.draw()
            self.esc_menu.draw()

            pygame.transform.scale(
                self.screen, (const.WIDTH, const.HEIGHT), self.real_screen
            )
            pygame.display.flip()

            # Yield to the browser once per frame, which pygbag needs to keep the
            # page responsive. On the desktop this returns immediately.
            await asyncio.sleep(0)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif self.esc_menu.visible:
                self.handle_esc_menu_input(event)
            elif event.type == pygame.KEYDOWN:
                self.on_keydown(event)
            elif event.type == pygame.KEYUP:
                self.on_keyup(event)

    def handle_esc_menu_input(self, event):
        action = self.esc_menu.handle_input(event)
        if not self.esc_menu.visible:
            util.unpause_sounds()
        self.handle_esc_menu_action(action)

    def handle_esc_menu_action(self, action):
        if action == "exit":
            sys.exit()
        elif action == "restart":
            self.flow_mgr.restart()
        elif action == "new_game":
            self.new_game()
        elif action == "toggle_music":
            self.toggle_music()
        elif action == "toggle_fullscreen":
            self.toggle_fullscreen()

    def update(self, dt):
        self.flow_mgr.update(dt)
        if self.flow_mgr.is_charging():
            self.character_con.update(dt)
            self.checkpoint_indicator_mgr.show_charging()
            return
        if self.flow_mgr.is_finished():
            self.character_con.update(dt)
            return
        if not self.flow_mgr.is_playing():
            return

        self.character_con.update(dt)
        self.world_mgr.update(dt, self.character)
        self.preview_mgr.update(dt)
        self.tether_mgr.update(dt)
        self.checkpoint_indicator_mgr.update(dt)
        self.camera_mgr.follow(self.world_mgr.clock)

    def draw(self):
        self.world_mgr.draw(self.screen)
        self.preview_mgr.draw(self.screen)
        self.tether_mgr.draw(self.screen)
        self.checkpoint_indicator_mgr.draw(self.screen)
        self.camera_mgr.draw(self.screen, self.character_con)
        self.world_mgr.draw_carried(self.screen)
        self.preview_mgr.draw_cross(self.screen)
        self.screen.blit(self.fg, (0, 0))
        self.tutorial_mgr.draw(self.screen)
        self.flow_mgr.draw(self.screen)

    def on_keydown(self, event):
        if self.flow_mgr.is_finished() and event.key in const.JUMP_KEYS:
            self.done = True
        elif event.key in const.ESC_MENU_KEYS:
            # We release held keys now because the Esc menu swallows their key-ups.
            self.character.release_all()
            self.esc_menu.show()

            # We pause the sound effects along with play, but leave the music on.
            util.pause_sounds()
        elif event.key in const.FULLSCREEN_KEYS:
            self.toggle_fullscreen()
        elif event.key in const.JUMP_KEYS:
            self.press_jump()
        elif event.key in const.LEFT_KEYS:
            self.character.move_left()
        elif event.key in const.RIGHT_KEYS:
            self.character.move_right()

    def press_jump(self):
        # We drop jump presses outside play, so a key held through a pause does not
        # fire late.
        if self.flow_mgr.is_playing():
            self.character.jump_press()

    def on_keyup(self, event):
        if event.key in const.RESTART_KEYS:
            self.flow_mgr.restart()
        elif event.key in const.LEFT_KEYS:
            self.character.stop_left()
        elif event.key in const.RIGHT_KEYS:
            self.character.stop_right()

    def toggle_fullscreen(self):
        # We let the browser own fullscreen on the web, since the page cannot
        # resize its own display.
        if const.IS_WEB:
            util.toggle_web_fullscreen()
            return

        self.fullscreen = not self.fullscreen
        flags = (pygame.FULLSCREEN | pygame.SCALED) if self.fullscreen else 0
        pygame.display.set_mode((const.WIDTH, const.HEIGHT), flags)

    def toggle_music(self):
        self.music_enabled = not self.music_enabled
        try:
            if self.music_enabled:
                pygame.mixer.music.unpause()
            else:
                pygame.mixer.music.pause()
        except pygame.error:
            pass

    def new_game(self):
        self._reset_run()
        self.flow_mgr.new_game()

    def resume(self):
        # We respawn at the saved checkpoint rather than start a new game, so
        # finishing the game keeps its progress.
        self._reset_run()
        self.flow_mgr.respawn()

    def _reset_run(self):
        self.done = False

        # We release held keys because the main menu swallows their key-ups.
        self.character.release_all()

    def die(self, message):
        self.flow_mgr.die(message)

    def reach_checkpoint(self, checkpoint):
        self.flow_mgr.reach_checkpoint(checkpoint)

    def finish(self):
        self.flow_mgr.finish()

    def respawn(self, checkpoint):
        self.world_mgr.reset_to_checkpoint(checkpoint)
        level_clock = self.world_mgr.clock
        self.character.place_on(level_clock)
        self.camera_mgr.follow(level_clock)
        self.preview_mgr.hide()
        self.tether_mgr.hide()
        self.checkpoint_indicator_mgr.hide()


class CameraManager:

    def __init__(self):
        # In map coordinates.
        self.view_rect = pygame.Rect(0, 0, const.REAL_WIDTH, const.REAL_HEIGHT)

    def follow(self, level_clock):
        # We follow the clock's whole-pixel rect rather than its pos, so the map
        # never jitters by a subpixel against the clock.
        self.view_rect.topleft = (
            level_clock.rect.centerx - const.CLOCK_SCREEN_POS[0],
            level_clock.rect.centery - const.CLOCK_SCREEN_POS[1],
        )

    def is_visible(self, rect):
        return self.view_rect.colliderect(rect)

    def to_screen(self, rect):
        return rect.move(-self.view_rect.left, -self.view_rect.top)

    def to_screen_pos(self, pos):
        return (pos[0] - self.view_rect.left, pos[1] - self.view_rect.top)

    def draw(self, surface, sprites):
        for sprite in sprites:
            if self.is_visible(sprite.rect):
                surface.blit(sprite.image, self.to_screen(sprite.rect))


class FlowManager:

    def __init__(self, world_mgr, character, respawn_fn):
        self.world_mgr = world_mgr
        self.character = character
        self.respawn_fn = respawn_fn
        self.checkpoint = util.load_checkpoint(world_mgr.get_checkpoint_count())

        # Phase states.
        self.phase = "holding"
        self.timer = 0.0

        self.sprites = pygame.sprite.Group()
        self.death_sound = util.load_sound("death.ogg", const.DEATH_SOUND_VOLUME)
        self.respawn()

    def respawn(self):
        self.respawn_fn(self.checkpoint)
        self.sprites.empty()
        self.phase = "holding"
        self.timer = const.RESPAWN_HOLD

    def restart(self):
        self.respawn()

    def new_game(self):
        self.checkpoint = 0
        util.write_checkpoint(self.checkpoint)
        self.respawn()

    def update(self, dt):
        if self.phase == "holding":
            self.update_holding(dt)
        elif self.phase == "charging":
            self.update_charging(dt)
        elif self.phase == "dying":
            self.update_dying(dt)

    def draw(self, surface):
        self.sprites.draw(surface)

    def is_playing(self):
        return self.phase == "playing"

    def is_charging(self):
        return self.phase == "charging"

    def is_finished(self):
        return self.phase == "finished"

    def update_holding(self, dt):
        self.timer -= dt
        if self.timer > 0:
            return
        self.start_playing()

    def start_playing(self):
        # We start the leg directly since the character paid for this checkpoint
        # before it died.
        if self.checkpoint > 0:
            self.world_mgr.clock.start_glide()
        self.phase = "playing"

    def reach_checkpoint(self, checkpoint):
        if self.phase != "playing":
            return
        if not self.character.is_standing_on(self.world_mgr.clock):
            self.die(const.STAY_MESSAGE)
            return
        if not self.world_mgr.is_carrying_energy():
            self.die(const.POWER_MESSAGE)
            return
        self.world_mgr.consume_energy()
        self.checkpoint = checkpoint
        util.write_checkpoint(self.checkpoint)
        self.start_charging()

    def start_charging(self):
        self.phase = "charging"
        self.timer = const.CHARGE_ANIMATION_TIME + const.CHARGE_HOLD_TIME
        self.character.start_charging()

    def update_charging(self, dt):
        level_clock = self.world_mgr.clock
        was_animating = self.timer > const.CHARGE_HOLD_TIME
        self.timer -= dt
        if was_animating and self.timer <= const.CHARGE_HOLD_TIME:
            level_clock.start_flash(const.CHARGE_HOLD_TIME, const.CHARGE_FLASH_COUNT)
        else:
            level_clock.update_flash(dt)
        if self.timer > 0:
            return

        self.character.stop_charging()
        level_clock.stop_flash()
        level_clock.start_glide()
        self.phase = "playing"

    def finish(self):
        if self.phase != "playing":
            return
        self.phase = "finished"
        self.character.start_celebrating()

    def die(self, message):
        if self.phase != "playing":
            return
        self.phase = "dying"
        self.timer = const.DEATH_MESSAGE_TIME

        # We silence the clock because a death halts it, even in the middle of a
        # glide.
        self.world_mgr.clock.stop_move_sound()
        self.death_sound.play()

        bottom_center = (
            const.REAL_WIDTH / 2,
            const.REAL_HEIGHT - const.DEATH_MESSAGE_MARGIN,
        )
        self.sprites.add(
            util.create_display_text(message, bottom_center, anchor=(0.5, 1))
        )

    def update_dying(self, dt):
        self.timer -= dt
        if self.timer > 0:
            return

        # We skip the respawn hold since the death message already held play.
        self.respawn()
        self.start_playing()


class Character(pygame.sprite.Sprite):

    def __init__(self, world_mgr, camera_mgr, die_fn):
        super().__init__()
        self.pos = [0.0, 0.0]  # Placed on the clock at each respawn.
        self.world_mgr = world_mgr
        self.camera_mgr = camera_mgr
        self.die_fn = die_fn
        self.image_ss = pygame.image.load(
            data.filepath("character_ss.png")
        ).convert_alpha()
        self.images = util.slice_sprite_sheet(
            self.image_ss, const.CHARACTER_SIZE, const.CHARACTER_SIZE
        )
        self.image_right = self.images[0][0]
        self.image_left = self.images[1][0]
        self.image_walk_right = util.Animation(self.images[0][1:5], 0.15, loop=True)
        self.image_walk_left = util.Animation(self.images[1][1:5], 0.15, loop=True)
        self.image_jump_right = self.images[2][0]
        self.image_jump_left = self.images[2][1]
        self.image_charging = self._create_charging_animation(self.images[3])
        self.image_celebrate = util.Animation(
            [self.image_jump_left, self.image_jump_right],
            const.CELEBRATE_FRAME_TIME,
            loop=True,
        )
        self.image = self.image_right
        self.facing_right = True
        self.rect = self.image.get_rect()

        # Character collision is thinner.
        self.collision_rect = pygame.Rect(0, 0, self.rect.width - 10, self.rect.height)
        self._sync_rects()

        # Movement states.
        self.vel = [0.0, 0.0]
        self.grounded = False
        self.ridden_clock = None  # Clock the character stands on.

        # Freeze states.
        self.frozen = False
        self.freeze_offset = [0, 0]  # From the clock's center to the character.
        self.image_unfrozen = self.image  # The frame the freeze tinted.
        self.leg_start = [0.0, 0.0]
        self.leg_end = [0.0, 0.0]
        self.gold_impact = None  # Fraction of the leg where a gold block hits.
        self.jump_queued = False  # Fires once the character lands.

        # Charge states.
        self.charging = False

        # Celebration states.
        self.celebrating = False

        # Timers.
        self.jump_boost_timer = 0.0
        self.coyote_timer = 0.0
        self.freeze_jump_timer = 0.0

        # Input states.
        self.move_x = 0
        self.jump_pressed = False

        self.jump_sound = util.load_sound("jump.ogg", const.JUMP_SOUND_VOLUME)
        self.launch_sound = util.load_sound("launch.ogg", const.LAUNCH_SOUND_VOLUME)
        self.charge_sound = util.load_sound("charge.ogg", const.CHARGE_SOUND_VOLUME)

    def _create_charging_animation(self, frames):
        frame_time = const.CHARGE_ANIMATION_TIME / (len(frames) - 1)
        intervals = [frame_time] * (len(frames) - 1) + [const.CHARGE_HOLD_TIME]
        return util.Animation(frames, intervals, loop=False)

    def _sync_rects(self):
        self.rect.center = self.pos
        self.collision_rect.center = self.pos

    def update(self, dt):
        if self.charging:
            self.image.update(dt)
            return
        if self.celebrating:
            self.update_celebrating(dt)
            return

        self.update_freeze()
        if self.frozen:
            self.update_frozen(dt)
            return

        self.update_movement(dt)
        self.update_position(dt)
        if not self.camera_mgr.is_visible(self.rect):
            self.die_fn(const.FAR_MESSAGE)
            return

        self.update_image(dt)
        if self.jump_boost_timer > 0:
            self.jump_boost_timer -= dt
        self.jump_pressed = False

    def update_image(self, dt):
        if self.move_x != 0:
            self.facing_right = self.move_x > 0

        if not self.grounded:
            self.image = (
                self.image_jump_right if self.facing_right else self.image_jump_left
            )
        elif self.move_x != 0:
            self.image = (
                self.image_walk_right if self.facing_right else self.image_walk_left
            )
        else:
            self.image = self.image_right if self.facing_right else self.image_left

        if isinstance(self.image, util.Animation):
            self.image.update(dt)

    def update_celebrating(self, dt):
        self.image_celebrate.update(dt)
        self.image = self.image_celebrate

    def update_freeze(self):
        level_clock = self.world_mgr.clock
        if level_clock.gliding and not self.frozen:
            self.freeze(level_clock)

    def freeze(self, level_clock):
        self.frozen = True
        self.freeze_offset = [
            self.pos[0] - level_clock.rect.centerx,
            self.pos[1] - level_clock.rect.centery,
        ]
        self.image_unfrozen = self.image
        self.image = util.tint(self.image, const.FREEZE_TINT_COLOR, const.FREEZE_ALPHA)
        self.leg_start = list(self.pos)
        self.leg_end = self.get_leg_end(level_clock)
        self.gold_impact = self.find_gold_impact(self.leg_start, self.leg_end)

        # We judge the jump by the moment the clock takes over, as coyote time
        # does, not by where the character lands.
        self.jump_queued = False
        self.freeze_jump_timer = const.FREEZE_JUMP_TIME if self._can_jump() else 0.0

    def update_frozen(self, dt):
        # We check before counting down so a press on the freeze frame always
        # counts, and drop every press so a late one never fires.
        if self.jump_pressed and self.freeze_jump_timer > 0:
            self.jump_queued = True
        self.freeze_jump_timer = max(0.0, self.freeze_jump_timer - dt)
        self.jump_pressed = False

    def get_leg_end(self, level_clock):
        start_node, target_node = level_clock.get_next_leg()
        return [
            self.pos[0] + target_node[0] - start_node[0],
            self.pos[1] + target_node[1] - start_node[1],
        ]

    def follow(self, level_clock):
        if self._has_hit_gold(level_clock):
            self.smash()
            return

        self.pos = [
            level_clock.rect.centerx + self.freeze_offset[0],
            level_clock.rect.centery + self.freeze_offset[1],
        ]
        self._sync_rects()

        # We land in the frame the clock arrives, so a crush shows the character
        # still inside the solid.
        if not level_clock.gliding:
            self.unfreeze()

    def _has_hit_gold(self, level_clock):
        if self.gold_impact is None:
            return False
        return level_clock.get_glide_progress() >= self.gold_impact

    def smash(self):
        self.pos = util.get_point_along(self.leg_start, self.leg_end, self.gold_impact)
        self._sync_rects()
        self.image = util.tint(
            self.image_unfrozen, const.DEATH_TINT_COLOR, const.FREEZE_ALPHA
        )
        self.die_fn(const.GOLD_MESSAGE)

    def unfreeze(self):
        landing = self.find_landing(self.pos)
        if landing is None:
            self.crush()
            return

        self.frozen = False
        self.ridden_clock = None
        self.pos = landing
        self._sync_rects()
        if self.jump_queued:
            self.jump()

    def crush(self):
        self.image = util.tint(
            self.image_unfrozen, const.DEATH_TINT_COLOR, const.FREEZE_ALPHA
        )
        self.die_fn(const.CRUSHED_MESSAGE)

    def find_landing(self, pos):
        # We skip the clock because a character that follows it keeps the same
        # overlap with it, and the clock contacts resolve any stray pixel.
        nearby_blocks = self.world_mgr.get_solid_blocks(self._get_nearby_rect(pos))
        solid_rects = [block.rect for block in nearby_blocks]
        if self._is_embedded(pos, solid_rects):
            return None

        landing = list(pos)
        for solid_rect in solid_rects:
            if self._get_collision_rect_at(landing).colliderect(solid_rect):
                landing = self._get_pushed_pos(landing, solid_rect)

        # A push may land the character in another solid, which squeezes it.
        if self._get_collision_rect_at(landing).collidelist(solid_rects) != -1:
            return None
        return landing

    def find_gold_impact(self, start, end):
        leg_rect = self._get_collision_rect_at(start).union(
            self._get_collision_rect_at(end)
        )
        impacts = [
            self._get_sweep_entry(start, end, block.rect)
            for block in self.world_mgr.get_gold_blocks(leg_rect)
        ]
        return min((impact for impact in impacts if impact is not None), default=None)

    def _get_sweep_entry(self, start, end, obj_rect):
        # We grow the rect by half the collision rect, so the sweep reduces to the
        # center crossing it. Merely touching an edge, as when sliding along a
        # block, is not a hit.
        half_width = self.collision_rect.width / 2
        half_height = self.collision_rect.height / 2
        entry_x, exit_x = _get_slab_span(
            start[0], end[0], obj_rect.left - half_width, obj_rect.right + half_width
        )
        entry_y, exit_y = _get_slab_span(
            start[1], end[1], obj_rect.top - half_height, obj_rect.bottom + half_height
        )
        entry = max(entry_x, entry_y, 0.0)
        exit_ = min(exit_x, exit_y, 1.0)
        if entry >= exit_:
            return None
        return entry

    def _get_nearby_rect(self, pos):
        # A tile of margin on each side covers any single push or frame of movement.
        margin = 2 * const.TILE_SIZE
        return self._get_collision_rect_at(pos).inflate(margin, margin)

    def _is_embedded(self, pos, solid_rects):
        collision_rect = self._get_collision_rect_at(pos)
        overlap_area = 0
        for solid_rect in solid_rects:
            overlap = collision_rect.clip(solid_rect)
            overlap_area += overlap.width * overlap.height
        character_area = collision_rect.width * collision_rect.height
        return overlap_area >= character_area * const.MAX_FREEZE_OVERLAP

    def _get_collision_rect_at(self, pos):
        collision_rect = self.collision_rect.copy()
        collision_rect.center = pos
        return collision_rect

    def _get_pushed_pos(self, pos, obj_rect):
        collision_rect = self._get_collision_rect_at(pos)
        overlap_top = collision_rect.bottom - obj_rect.top
        overlap_bottom = obj_rect.bottom - collision_rect.top
        overlap_left = collision_rect.right - obj_rect.left
        overlap_right = obj_rect.right - collision_rect.left
        smallest = min(overlap_top, overlap_bottom, overlap_left, overlap_right)

        if smallest == overlap_top:
            return [pos[0], obj_rect.top - collision_rect.height / 2]
        if smallest == overlap_bottom:
            return [pos[0], obj_rect.bottom + collision_rect.height / 2]
        if smallest == overlap_left:
            return [obj_rect.left - collision_rect.width / 2, pos[1]]
        return [obj_rect.right + collision_rect.width / 2, pos[1]]

    def update_movement(self, dt):
        # Horizontal movement.
        if self.move_x != 0:
            self.vel[0] = util.move_towards(
                self.vel[0], self.move_x * const.MAX_MOVE_SPEED, const.MOVE_ACCEL * dt
            )
        else:
            self.vel[0] = util.move_towards(self.vel[0], 0, const.MOVE_DECEL * dt)

        # Coyote time.
        if self.grounded:
            self.coyote_timer = const.COYOTE_TIME
        else:
            self.coyote_timer = max(0, self.coyote_timer - dt)

        # Vertical movement.
        if not self.grounded:
            self.vel[1] += self._get_gravity() * dt
            self.vel[1] = min(self.vel[1], const.MAX_FALL_SPEED)

        if self.jump_pressed and self._can_jump():
            self.jump()

    def _can_jump(self):
        return self.grounded or self.coyote_timer > 0

    def _get_gravity(self):
        if self.jump_boost_timer > 0 and self.vel[1] < 0:
            return const.GRAVITY * const.JUMP_BOOST_GRAVITY_SCALE
        return const.GRAVITY

    def update_position(self, dt):
        self.pos[0] += self.vel[0] * dt
        self._sync_rects()
        self.handle_collisions_horizontal()

        prev_bottom = self.pos[1] + self.collision_rect.height / 2
        self.pos[1] += self.vel[1] * dt
        self._sync_rects()
        self.handle_collisions_vertical(prev_bottom)

    def handle_collisions_horizontal(self):
        nearby_rect = self._get_nearby_rect(self.pos)
        for obj in self.world_mgr.get_collision_objects(nearby_rect):
            if not self.collision_rect.colliderect(obj.rect):
                continue
            if self.vel[0] > 0:
                self.pos[0] = obj.rect.left - self.collision_rect.width / 2
            elif self.vel[0] < 0:
                self.pos[0] = obj.rect.right + self.collision_rect.width / 2
            else:
                # When vel[0] == 0, push in direction with least displacement.
                overlap_left = self.collision_rect.right - obj.rect.left
                overlap_right = obj.rect.right - self.collision_rect.left
                if overlap_left < overlap_right:
                    self.pos[0] = obj.rect.left - self.collision_rect.width / 2
                else:
                    self.pos[0] = obj.rect.right + self.collision_rect.width / 2
            self.vel[0] = 0
            self._sync_rects()
            return

    def handle_collisions_vertical(self, prev_bottom):
        nearby_rect = self._get_nearby_rect(self.pos)
        for obj in self.world_mgr.get_collision_objects(nearby_rect):
            if not self.collision_rect.colliderect(obj.rect):
                continue
            if self.vel[1] > 0:
                self.pos[1] = obj.rect.top - self.collision_rect.height / 2
                self._land_on(obj)
            else:
                self.pos[1] = obj.rect.bottom + self.collision_rect.height / 2
                self.jump_boost_timer = 0
            self.vel[1] = 0
            self._sync_rects()
            return

        if self.vel[1] > 0 and self._land_on_platform(nearby_rect, prev_bottom):
            return

        # If no vertical collision, check if we should still be grounded.
        if self.vel[1] > 0:
            self.grounded = False
        elif self.grounded and self.vel[1] >= 0:
            self.ridden_clock = self._find_clock_below()
            self.grounded = self.ridden_clock is not None or self._is_on_ground()

    def is_standing_on(self, level_clock):
        return self.grounded and self.ridden_clock is level_clock

    def _land_on_platform(self, nearby_rect, prev_bottom):
        # We land only if the feet crossed the top during this move, so the
        # character can jump up through a platform from below or the side. We
        # compare float positions because the rect truncates them, and feet that
        # stop inside the top pixel would otherwise never register a landing.
        bottom = self.pos[1] + self.collision_rect.height / 2
        for platform in self.world_mgr.get_platforms(nearby_rect):
            if not self._overlaps_horizontally(platform.rect):
                continue
            if not prev_bottom <= platform.rect.top < bottom:
                continue
            self.pos[1] = platform.rect.top - self.collision_rect.height / 2
            self.vel[1] = 0
            self._land_on(platform)
            self._sync_rects()
            return True
        return False

    def _overlaps_horizontally(self, obj_rect):
        return (
            self.collision_rect.left < obj_rect.right
            and self.collision_rect.right > obj_rect.left
        )

    def _land_on(self, obj):
        self.grounded = True
        self.ridden_clock = obj if isinstance(obj, world.Clock) else None

    def _find_clock_below(self):
        level_clock = self.world_mgr.clock
        probe = self.collision_rect.move(0, 1)
        if not probe.colliderect(level_clock.rect):
            return None
        return level_clock

    def _is_on_ground(self):
        below_y = self.pos[1] + self.collision_rect.height / 2 + 1
        half_width = self.collision_rect.width / 2
        return any(
            self.world_mgr.is_solid_at_xy(x, below_y)
            or self.world_mgr.is_platform_top_at_xy(x, below_y)
            for x in (self.pos[0] - half_width, self.pos[0] + half_width)
        )

    def ride(self, delta):
        self.pos[0] += delta[0]
        self.pos[1] += delta[1]
        self._sync_rects()

    def push_out_of(self, obj):
        pushed_pos = self._get_pushed_pos(self.pos, obj.rect)
        if pushed_pos[1] < self.pos[1] and self.vel[1] >= 0:
            self.vel[1] = 0
            self._land_on(obj)
        elif pushed_pos[1] > self.pos[1] and self.vel[1] < 0:
            self.vel[1] = 0
            self.jump_boost_timer = 0
        self.pos = pushed_pos
        self._sync_rects()

    def start_charging(self):
        self.charging = True
        self.vel = [0.0, 0.0]
        self.image_charging.reset()
        self.image = self.image_charging
        self.charge_sound.play()

    def stop_charging(self):
        self.charging = False

    def start_celebrating(self):
        self.celebrating = True
        self.vel = [0.0, 0.0]
        self.image_celebrate.reset()
        self.image = self.image_celebrate

    def jump(self):
        self.vel[1] = -const.JUMP_SPEED
        self.jump_boost_timer = const.JUMP_BOOST_TIME
        self.grounded = False
        self.jump_sound.play()

    def launch(self):
        self.vel[1] = -const.LAUNCHER_SPEED
        self.grounded = False
        self.ridden_clock = None

        # We clear the jump timers so a late jump press cannot weaken the launch
        # and every launch reaches the same height.
        self.coyote_timer = 0.0
        self.jump_boost_timer = 0.0
        self.launch_sound.play()

    def place_on(self, level_clock):
        self.pos = [
            level_clock.rect.centerx,
            level_clock.rect.top - self.collision_rect.height / 2,
        ]
        self.vel = [0.0, 0.0]
        self._sync_rects()
        self.grounded = True
        self.ridden_clock = level_clock
        self.frozen = False
        self.charging = False
        self.celebrating = False
        self.jump_pressed = False
        self.image = self.image_right if self.facing_right else self.image_left

    # Input methods.
    def move_left(self):
        self.move_x = -1

    def stop_left(self):
        if self.move_x < 0:
            self.move_x = 0

    def move_right(self):
        self.move_x = 1

    def stop_right(self):
        if self.move_x > 0:
            self.move_x = 0

    def jump_press(self):
        self.jump_pressed = True

    def release_all(self):
        self.move_x = 0
        self.jump_pressed = False


class PreviewManager:

    def __init__(self, character, world_mgr, camera_mgr):
        self.character = character
        self.world_mgr = world_mgr
        self.camera_mgr = camera_mgr
        self.dots = PreviewDots()
        self.ghost = PreviewGhost()
        self.clock_ghost = PreviewGhost()
        self.cross = PreviewCross()

        # Sorted by draw order.
        self.sprites = pygame.sprite.Group(self.clock_ghost, self.dots, self.ghost)

    def update(self, dt):
        level_clock = self.world_mgr.clock
        if self.character.frozen:
            self.dots.redraw(level_clock.get_glide_progress())
            return
        self.plan(level_clock)

    def draw(self, surface):
        self.camera_mgr.draw(surface, self.sprites)

    def draw_cross(self, surface):
        self.camera_mgr.draw(surface, [self.cross])

    def plan(self, level_clock):
        self.show_clock_ghost(level_clock)
        if self.is_checkpoint_unready(level_clock):
            self.show_unready()
            return

        start = list(self.character.pos)
        end = self.character.get_leg_end(level_clock)
        if start == end:
            self.hide()
            return

        gold_impact = self.character.find_gold_impact(start, end)
        if gold_impact is None:
            stop = 1.0
            fatal = self.character.find_landing(end) is None
        else:
            stop = gold_impact
            fatal = True
        ghost_pos = util.get_point_along(start, end, stop)
        self.dots.show(start, end, stop, fatal)
        self.ghost.show(self.character.image, ghost_pos, fatal)
        if fatal:
            self.cross.show(ghost_pos)
        else:
            self.cross.hide()

    def show_clock_ghost(self, level_clock):
        # We keep the clock ghost blue even on a fatal leg, since only the
        # character dies.
        _, target_node = level_clock.get_next_leg()
        self.clock_ghost.show(level_clock.image_rest, target_node, False)

    def is_checkpoint_unready(self, level_clock):
        if not level_clock.is_checkpoint_leg():
            return False

        # We plan once more on the frame charging starts, after the charge has
        # used up the energy it paid for this leg with.
        if self.character.charging:
            return False
        if not self.character.is_standing_on(level_clock):
            return True
        return not self.world_mgr.is_carrying_energy()

    def show_unready(self):
        self.dots.hide()
        self.ghost.hide()
        self.cross.show(self.character.pos)

    def hide(self):
        self.dots.hide()
        self.ghost.hide()
        self.clock_ghost.hide()
        self.cross.hide()


class PreviewDots(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()

        # Leg states.
        self.start = [0, 0]
        self.end = [0, 0]
        self.fractions = []  # Along the leg, from 0 at the start to 1 at the end.
        self.color = const.FREEZE_TINT_COLOR

        self.hide()

    def show(self, start, end, stop, fatal):
        self.start = start
        self.end = end
        length = math.dist(start, end)
        dot_count = math.ceil(length / const.PREVIEW_DOT_SPACING)

        # We space the dots along the whole leg, so their fractions stay in step
        # with the glide's progress even when the leg stops short.
        fractions = [
            i * const.PREVIEW_DOT_SPACING / length for i in range(1, dot_count)
        ]
        self.fractions = [fraction for fraction in fractions if fraction < stop]
        self.color = (*_get_tint_color(fatal), const.PREVIEW_DOT_ALPHA)
        self.redraw(0.0)

    def hide(self):
        # We drop the fractions too, so a later redraw cannot draw a stale leg.
        self.fractions = []
        self.image = pygame.Surface((0, 0))
        self.rect = pygame.Rect(0, 0, 0, 0)

    def redraw(self, progress):
        # The clock and the frozen character share this progress, so a dot
        # vanishes as the character's center reaches it.
        points = [
            self._get_point(fraction)
            for fraction in self.fractions
            if fraction > progress
        ]
        if not points:
            self.hide()
            return

        radius = const.PREVIEW_DOT_RADIUS
        left = min(point[0] for point in points) - radius
        top = min(point[1] for point in points) - radius
        right = max(point[0] for point in points) + radius
        bottom = max(point[1] for point in points) + radius
        self.rect = pygame.Rect(left, top, right - left + 1, bottom - top + 1)
        self.image = pygame.Surface(self.rect.size, pygame.SRCALPHA)
        for point in points:
            local = (point[0] - left, point[1] - top)
            pygame.draw.circle(self.image, self.color, local, radius)

    def _get_point(self, fraction):
        return (
            round(self.start[0] + (self.end[0] - self.start[0]) * fraction),
            round(self.start[1] + (self.end[1] - self.start[1]) * fraction),
        )


class PreviewGhost(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.hide()

    def show(self, image_character, pos, fatal):
        tint_color = _get_tint_color(fatal)
        self.image = util.tint(image_character, tint_color, const.FREEZE_ALPHA)
        self.rect = self.image.get_rect()
        self.rect.center = pos

    def hide(self):
        self.image = pygame.Surface((0, 0))
        self.rect = pygame.Rect(0, 0, 0, 0)


class PreviewCross(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.image_cross = self._create_cross_image()
        self.hide()

    def _create_cross_image(self):
        size = const.PREVIEW_CROSS_SIZE
        last = size - 1
        image = pygame.Surface((size, size), pygame.SRCALPHA)
        for start, end in (((0, 0), (last, last)), ((0, last), (last, 0))):
            pygame.draw.line(
                image, const.DEATH_TINT_COLOR, start, end, const.PREVIEW_CROSS_WIDTH
            )
        return image

    def show(self, pos):
        self.image = self.image_cross
        self.rect = self.image.get_rect()
        self.rect.center = pos

    def hide(self):
        self.image = pygame.Surface((0, 0))
        self.rect = pygame.Rect(0, 0, 0, 0)


class TetherManager:

    def __init__(self, character, world_mgr, camera_mgr):
        self.character = character
        self.world_mgr = world_mgr
        self.camera_mgr = camera_mgr
        self.tether = Tether()
        self.sprites = pygame.sprite.Group(self.tether)

    def update(self, dt):
        if not self.character.frozen:
            self.tether.hide()
            return

        level_clock = self.world_mgr.clock
        clock_gap = const.CLOCK_SIZE / 2
        self.tether.show(level_clock.rect.center, self.character.pos, clock_gap, dt)

    def draw(self, surface):
        self.camera_mgr.draw(surface, self.sprites)

    def hide(self):
        self.tether.hide()


class Tether(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()

        # Wave states.
        self.start = [0.0, 0.0]
        self.direction = (0.0, 0.0)
        self.length = 0.0
        self.phase = 0.0  # Distance the wave has traveled, in pixels.

        self.hide()

    def show(self, clock_center, character_pos, clock_gap, dt):
        self.direction = util.get_normalized_vector(clock_center, character_pos)
        center_distance = util.distance(clock_center, character_pos)
        self.length = center_distance - clock_gap
        if self.length <= 0:
            self.hide()
            return

        self.start = [
            clock_center[0] + self.direction[0] * clock_gap,
            clock_center[1] + self.direction[1] * clock_gap,
        ]
        self.phase += dt * const.TETHER_WAVE_SPEED
        self.phase %= const.TETHER_WAVELENGTH
        self.redraw()

    def hide(self):
        self.image = pygame.Surface((0, 0))
        self.rect = pygame.Rect(0, 0, 0, 0)

    def redraw(self):
        points = self._get_points()
        padding = const.TETHER_GLOW_WIDTH
        left = math.floor(min(point[0] for point in points)) - padding
        top = math.floor(min(point[1] for point in points)) - padding
        right = math.ceil(max(point[0] for point in points)) + padding
        bottom = math.ceil(max(point[1] for point in points)) + padding
        self.rect = pygame.Rect(left, top, right - left + 1, bottom - top + 1)
        self.image = pygame.Surface(self.rect.size, pygame.SRCALPHA)

        local_points = [(point[0] - left, point[1] - top) for point in points]
        glow_color = (*const.TETHER_COLOR, const.TETHER_GLOW_ALPHA)
        core_color = (*const.TETHER_COLOR, const.TETHER_CORE_ALPHA)

        # We draw the core last so it overwrites the glow instead of stacking alpha.
        pygame.draw.lines(
            self.image, glow_color, False, local_points, const.TETHER_GLOW_WIDTH
        )
        pygame.draw.lines(
            self.image, core_color, False, local_points, const.TETHER_CORE_WIDTH
        )

    def _get_points(self):
        segment_count = max(2, math.ceil(self.length / const.TETHER_SEGMENT_LENGTH))
        normal = (-self.direction[1], self.direction[0])
        points = []
        for i in range(segment_count + 1):
            fraction = i / segment_count
            along = self.length * fraction
            offset = self._get_offset(along)
            points.append(
                (
                    self.start[0] + self.direction[0] * along + normal[0] * offset,
                    self.start[1] + self.direction[1] * along + normal[1] * offset,
                )
            )
        return points

    def _get_offset(self, along):
        wave = math.sin(2 * math.pi * (along - self.phase) / const.TETHER_WAVELENGTH)
        return const.TETHER_AMPLITUDE * wave


class CheckpointIndicatorManager:

    def __init__(self, character, world_mgr, camera_mgr):
        self.character = character
        self.world_mgr = world_mgr
        self.camera_mgr = camera_mgr
        self.checkpoint_indicator = CheckpointIndicator()
        self.sprites = pygame.sprite.Group(self.checkpoint_indicator)

    def update(self, dt):
        level_clock = self.world_mgr.clock
        if not level_clock.is_waiting_on_checkpoint():
            self.hide()
            return

        safe = (
            self.character.is_standing_on(level_clock)
            and self.world_mgr.is_carrying_energy()
        )
        self.checkpoint_indicator.show(level_clock.rect.midtop, safe)

    def show_charging(self):
        level_clock = self.world_mgr.clock
        self.checkpoint_indicator.show_charging(level_clock.rect.midtop)

    def draw(self, surface):
        self.camera_mgr.draw(surface, self.sprites)

    def hide(self):
        self.checkpoint_indicator.hide()


class CheckpointIndicator(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.image_base = pygame.image.load(
            data.filepath("checkpoint_indicator.png")
        ).convert_alpha()
        self.image_safe = util.tint(
            self.image_base,
            const.CHECKPOINT_INDICATOR_SAFE_COLOR,
            const.CHECKPOINT_INDICATOR_SAFE_ALPHA,
        )
        self.image_unsafe = util.tint(
            self.image_base,
            const.CHECKPOINT_INDICATOR_UNSAFE_COLOR,
            const.CHECKPOINT_INDICATOR_UNSAFE_ALPHA,
        )
        self.image_charging = util.tint(
            self.image_base,
            const.GOLD_COLOR,
            const.CHECKPOINT_INDICATOR_CHARGING_ALPHA,
        )
        self.hide()

    def show(self, clock_top, safe):
        image = self.image_safe if safe else self.image_unsafe
        self._show_image(image, clock_top)

    def show_charging(self, clock_top):
        self._show_image(self.image_charging, clock_top)

    def _show_image(self, image, clock_top):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.midbottom = clock_top

    def hide(self):
        self.image = pygame.Surface((0, 0))
        self.rect = pygame.Rect(0, 0, 0, 0)


def _get_slab_span(start, end, low, high):
    # Return the fractions of the move between which the value lies strictly
    # inside (low, high), or an empty span when it never does.
    delta = end - start
    if delta == 0:
        if low < start < high:
            return -math.inf, math.inf
        return math.inf, -math.inf
    entry = (low - start) / delta
    exit_ = (high - start) / delta
    return min(entry, exit_), max(entry, exit_)


def _get_tint_color(fatal):
    if fatal:
        return const.DEATH_TINT_COLOR
    return const.FREEZE_TINT_COLOR
