# /// script
# dependencies = [
#     "pygame-ce",
# ]
# ///

# The block above tells pygbag to install pygame-ce in the browser. pygbag only
# scans this file's imports, and we import pygame inside gamelib.

import asyncio

from gamelib import main


asyncio.run(main.main())
