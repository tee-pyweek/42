<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tiles_ss" tilewidth="24" tileheight="24" tilecount="192" columns="16">
 <image source="tiles_ss.png" width="384" height="288"/>
</tileset>
